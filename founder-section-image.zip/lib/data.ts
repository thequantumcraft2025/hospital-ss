import { Heart, Bone, Baby, FlaskConical, Siren, Stethoscope } from "lucide-react"

export const departments = [
  {
    id: "cardiology",
    name: "Cardiology",
    icon: Heart,
    shortDescription: "Advanced cardiac care including angiography, PCI, and heart failure management.",
    fullDescription:
      "Our Cardiology department offers comprehensive cardiac care with state-of-the-art diagnostic and interventional facilities. From routine heart checkups to complex cardiac surgeries, our experienced cardiologists provide personalized treatment plans.",
    services: [
      "Echocardiography (2D, 3D, Stress Echo)",
      "Coronary Angiography & Angioplasty",
      "Pacemaker Implantation",
      "Heart Failure Management",
      "Cardiac Rehabilitation",
      "Preventive Cardiology",
    ],
    leadDoctor: { name: "Dr. Rajesh Kumar", slug: "dr-rajesh-kumar" },
    image: "/modern-cardiology-department-with-medical-equipmen.jpg",
  },
  {
    id: "orthopaedics",
    name: "Orthopaedics",
    icon: Bone,
    shortDescription: "Joint replacements, spine surgery, sports medicine, and trauma care.",
    fullDescription:
      "The Orthopaedics department at SS Hospital specializes in treating musculoskeletal conditions using minimally invasive techniques and advanced surgical procedures. Our team handles everything from fractures to complex joint replacements.",
    services: [
      "Total Knee & Hip Replacement",
      "Arthroscopic Surgery",
      "Spine Surgery",
      "Sports Injury Treatment",
      "Fracture Management",
      "Physiotherapy & Rehabilitation",
    ],
    leadDoctor: { name: "Dr. Venkatesh Murthy", slug: "dr-venkatesh-murthy" },
    image: "/orthopaedic-surgery-room-with-modern-equipment.jpg",
  },
  {
    id: "maternity",
    name: "Maternity Care",
    icon: Baby,
    shortDescription: "Complete maternity services from prenatal to postnatal care.",
    fullDescription:
      "Our Maternity department provides compassionate care for mothers and newborns. From prenatal checkups to delivery and postnatal support, we ensure a safe and comfortable experience for every family.",
    services: [
      "Prenatal Care & Monitoring",
      "Normal & Cesarean Delivery",
      "High-Risk Pregnancy Management",
      "Neonatal Intensive Care (NICU)",
      "Lactation Support",
      "Postnatal Care",
    ],
    leadDoctor: { name: "Dr. Lakshmi Devi", slug: "dr-lakshmi-devi" },
    image: "/modern-maternity-ward-with-comfortable-beds.jpg",
  },
  {
    id: "diagnostics",
    name: "Diagnostics & Lab",
    icon: FlaskConical,
    shortDescription: "State-of-the-art diagnostic imaging and pathology services.",
    fullDescription:
      "Our Diagnostics department is equipped with the latest imaging and laboratory technology. We provide accurate and timely results to support effective treatment decisions.",
    services: [
      "Digital X-Ray & CT Scan",
      "MRI Imaging",
      "Ultrasound & Doppler",
      "Complete Blood Analysis",
      "Biochemistry & Pathology",
      "Health Checkup Packages",
    ],
    leadDoctor: { name: "Dr. Suresh Babu", slug: "dr-suresh-babu" },
    image: "/modern-diagnostic-lab-with-ct-scanner.jpg",
  },
  {
    id: "surgery",
    name: "General Surgery",
    icon: Stethoscope,
    shortDescription: "Minimally invasive and open surgical procedures for various conditions.",
    fullDescription:
      "The General Surgery department performs a wide range of surgical procedures using both traditional and laparoscopic techniques. Our surgeons are experienced in handling complex cases with excellent outcomes.",
    services: [
      "Laparoscopic Surgery",
      "Hernia Repair",
      "Appendectomy",
      "Gallbladder Surgery",
      "Thyroid Surgery",
      "Gastrointestinal Surgery",
    ],
    leadDoctor: { name: "Dr. Karthik Reddy", slug: "dr-karthik-reddy" },
    image: "/modern-surgery-operating-room.jpg",
  },
  {
    id: "emergency",
    name: "Emergency Care",
    icon: Siren,
    shortDescription: "24/7 emergency services with rapid response and critical care.",
    fullDescription:
      "Our Emergency department operates round-the-clock with a dedicated team of emergency physicians, nurses, and support staff. We're equipped to handle all types of medical emergencies with speed and precision.",
    services: [
      "24/7 Emergency Response",
      "Trauma Care",
      "Critical Care Unit (ICU)",
      "Ambulance Services",
      "Emergency Surgery",
      "Poison & Overdose Management",
    ],
    leadDoctor: { name: "Dr. Anand Sharma", slug: "dr-anand-sharma" },
    image: "/hospital-emergency-room-entrance.jpg",
  },
]

export const doctors = [
  {
    id: "dr-rajesh-kumar",
    name: "Dr. Rajesh Kumar",
    qualification: "MD, DM (Cardiology)",
    specialty: "Cardiology",
    department: "cardiology",
    experience: "18 years",
    bio: "Dr. Rajesh Kumar is a renowned interventional cardiologist with expertise in complex angioplasties and structural heart interventions. He has performed over 5,000 cardiac procedures and is known for his patient-centric approach.",
    opDays: "Mon, Wed, Fri",
    opTime: "10:00 AM - 2:00 PM",
    languages: ["English", "Hindi", "Tamil", "Kannada"],
    image: "/professional-indian-male-cardiologist-doctor-portr.jpg",
  },
  {
    id: "dr-venkatesh-murthy",
    name: "Dr. Venkatesh Murthy",
    qualification: "MS, MCh (Ortho)",
    specialty: "Orthopaedics",
    department: "orthopaedics",
    experience: "22 years",
    bio: "Dr. Venkatesh Murthy specializes in joint replacement surgery and sports medicine. He has trained in Germany and performed over 3,000 successful joint replacements with excellent patient outcomes.",
    opDays: "Tue, Thu, Sat",
    opTime: "9:00 AM - 1:00 PM",
    languages: ["English", "Kannada", "Tamil"],
    image: "/professional-indian-male-orthopaedic-surgeon-docto.jpg",
  },
  {
    id: "dr-lakshmi-devi",
    name: "Dr. Lakshmi Devi",
    qualification: "MD, DGO",
    specialty: "Obstetrics & Gynaecology",
    department: "maternity",
    experience: "15 years",
    bio: "Dr. Lakshmi Devi is a compassionate obstetrician and gynaecologist specializing in high-risk pregnancies and laparoscopic procedures. She has safely delivered over 4,000 babies and is loved by her patients.",
    opDays: "Mon - Sat",
    opTime: "11:00 AM - 3:00 PM",
    languages: ["English", "Tamil", "Telugu"],
    image: "/professional-indian-female-gynaecologist-doctor-po.jpg",
  },
  {
    id: "dr-suresh-babu",
    name: "Dr. Suresh Babu",
    qualification: "MD (Radiology)",
    specialty: "Diagnostic Radiology",
    department: "diagnostics",
    experience: "12 years",
    bio: "Dr. Suresh Babu is an expert in diagnostic imaging with special interest in interventional radiology. He ensures accurate and timely diagnosis using the latest imaging technologies.",
    opDays: "Mon - Fri",
    opTime: "10:00 AM - 4:00 PM",
    languages: ["English", "Tamil", "Hindi"],
    image: "/professional-indian-male-radiologist-doctor-portra.jpg",
  },
  {
    id: "dr-karthik-reddy",
    name: "Dr. Karthik Reddy",
    qualification: "MS (General Surgery)",
    specialty: "General & Laparoscopic Surgery",
    department: "surgery",
    experience: "16 years",
    bio: "Dr. Karthik Reddy is a skilled general surgeon with extensive experience in laparoscopic and minimally invasive procedures. He is known for his surgical precision and quick recovery protocols.",
    opDays: "Mon, Wed, Fri",
    opTime: "2:00 PM - 6:00 PM",
    languages: ["English", "Telugu", "Kannada"],
    image: "/professional-indian-male-surgeon-doctor-portrait.jpg",
  },
  {
    id: "dr-anand-sharma",
    name: "Dr. Anand Sharma",
    qualification: "MD (Emergency Medicine)",
    specialty: "Emergency & Critical Care",
    department: "emergency",
    experience: "10 years",
    bio: "Dr. Anand Sharma leads our emergency department with expertise in trauma care and critical interventions. His quick decision-making and calm demeanor have saved countless lives.",
    opDays: "24/7 On-call",
    opTime: "Emergency Services",
    languages: ["English", "Hindi", "Tamil"],
    image: "/professional-indian-male-emergency-medicine-doctor.jpg",
  },
]

export const caseStudies = [
  {
    id: "successful-knee-replacement",
    title: "Successful Complex Knee Replacement",
    patient: "Mr. R (65 years, Hosur)",
    department: "Orthopaedics",
    summary:
      "65-year-old with severe osteoarthritis underwent total knee replacement; discharged on day 5; regained mobility in 8 weeks.",
    challenge:
      "Patient had severe bilateral knee osteoarthritis with significant bone loss and was unable to walk without support for 2 years.",
    intervention:
      "Performed computer-navigated total knee replacement with specialized implants designed for complex bone defects.",
    outcome:
      "Patient discharged on day 5, began walking with support on day 2, achieved full mobility within 8 weeks, and returned to normal activities.",
    doctor: "Dr. Venkatesh Murthy",
    image: "/knee-replacement-surgery-success.jpg",
  },
  {
    id: "cardiac-emergency-save",
    title: "Life-Saving Cardiac Intervention",
    patient: "Mrs. S (52 years, Krishnagiri)",
    department: "Cardiology",
    summary:
      "52-year-old with acute heart attack received emergency angioplasty within 45 minutes; full recovery achieved.",
    challenge:
      "Patient arrived with severe chest pain and ST-elevation myocardial infarction (STEMI), requiring immediate intervention.",
    intervention:
      "Emergency coronary angioplasty performed within 45 minutes of arrival, restoring blood flow to the blocked artery.",
    outcome:
      "Complete recovery with no heart muscle damage. Patient discharged in 4 days and returned to normal life within a month.",
    doctor: "Dr. Rajesh Kumar",
    image: "/cardiac-catheterization-lab.jpg",
  },
  {
    id: "high-risk-delivery",
    title: "High-Risk Twin Delivery Success",
    patient: "Mrs. P (34 years, Hosur)",
    department: "Maternity",
    summary:
      "High-risk twin pregnancy with gestational diabetes managed successfully; healthy twins delivered at 36 weeks.",
    challenge: "First-time mother with gestational diabetes carrying twins, one with intrauterine growth restriction.",
    intervention:
      "Close monitoring throughout pregnancy, controlled delivery via planned cesarean section at 36 weeks.",
    outcome:
      "Both healthy babies delivered weighing 2.4kg and 2.1kg. Mother and babies discharged in 5 days with excellent health.",
    doctor: "Dr. Lakshmi Devi",
    image: "/happy-mother-with-newborn-twins.jpg",
  },
]

export const blogPosts = [
  {
    id: "preparing-for-hospital-admission",
    title: "How to Prepare for Hospital Admission: A Short Checklist",
    excerpt:
      "Essential items and documents to bring for a smooth hospital stay. From medical records to personal comfort items.",
    category: "Patient Guide",
    date: "2024-11-15",
    readTime: "4 min read",
    image: "/hospital-admission-checklist.jpg",
  },
  {
    id: "signs-of-cardiac-emergency",
    title: "Signs of Cardiac Emergency: When to Visit the Hospital",
    excerpt:
      "Learn to recognize the warning signs of a heart attack. Early action saves lives - know when to seek emergency care.",
    category: "Health Tips",
    date: "2024-11-10",
    readTime: "5 min read",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: "free-health-camp-report",
    title: "SS Hospital Free Health Camp — Community Outreach Report",
    excerpt:
      "Over 500 residents benefited from our recent free health screening camp. See how we're serving the Hosur community.",
    category: "Hospital News",
    date: "2024-11-05",
    readTime: "3 min read",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: "understanding-joint-replacement",
    title: "Understanding Joint Replacement: Recovery Tips",
    excerpt:
      "What to expect before, during, and after joint replacement surgery. Tips for faster recovery and better outcomes.",
    category: "Patient Education",
    date: "2024-10-28",
    readTime: "6 min read",
    image: "/placeholder.svg?height=200&width=400",
  },
]
